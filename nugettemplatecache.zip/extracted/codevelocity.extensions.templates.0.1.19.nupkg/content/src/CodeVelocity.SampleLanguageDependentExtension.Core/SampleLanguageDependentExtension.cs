﻿namespace CodeVelocity.SampleLanguageDependentExtension.Core
{
    using System.Collections.Generic;
    using System.Diagnostics.CodeAnalysis;
    using System.Text;
    using CodeVelocity.Abstractions;
    using CodeVelocity.Extensions.Abstractions;
    using CodeVelocity.Extensions.Abstractions.Models;

    [ExcludeFromCodeCoverage]
    public class SampleLanguageDependentExtension : LanguageDependentExtensionBase
    {
        public SampleLanguageDependentExtension(ILanguageServerClient extensionLanguageClient)
            : base(extensionLanguageClient)
        {
        }

        public override string Id { get; protected set; } = "SampleLanguageDependentExtension";

        protected override IDictionary<Language, LanugageCommand> LanguageCommandOverrides { get; set; } = new Dictionary<Language, LanugageCommand>
        {
            { Language.Python, new LanugageCommand("samplelanguagedependentextension-python", "python python/SampleLanguageDependentExtension.py") },
            { Language.Javascript, new LanugageCommand("samplelanguagedependentextension-javascript", "node javascript/SampleLanguageDependentExtension.js") },
            { Language.CSharp | Language.Default, new LanugageCommand("samplelanguagedependentextension-csharp", "./csharp/CodeVelocity.SampleLanguageDependentExtension.Csharp") }
        };

        protected override ExtensionOutput AggregateLanguageOutputs(IDictionary<Language, ExtensionLanguageOutput> languageOutputs)
        {
            var totalFilesChanged = 0;
            var details = new StringBuilder("```\n");
            foreach (var languageOutput in languageOutputs)
            {
                details.AppendLine($"{languageOutput.Key}: {languageOutput.Value} files changed");
                totalFilesChanged += int.Parse(languageOutput.Value.StdOut);
            }

            details.AppendLine("```");

            var badge = new Badge(
                totalFilesChanged.ToString(),
                Severity.Warning);
            var markdownDetails = string.Format(
                @"## Sample language dependent extension:

{0}",
                details);

            var extensionOutput = new ExtensionOutput(badge, markdownDetails);
            return extensionOutput;
        }
    }
}
