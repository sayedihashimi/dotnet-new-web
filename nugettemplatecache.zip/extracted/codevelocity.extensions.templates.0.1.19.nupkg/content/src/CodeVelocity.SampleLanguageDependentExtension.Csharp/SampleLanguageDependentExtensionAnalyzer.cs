﻿namespace CodeVelocity.SampleLanguageDependentExtension.Csharp
{
    using System;
    using System.Collections.Generic;
    using CodeVelocity.Abstractions;
    using Newtonsoft.Json;

    public sealed class SampleLanguageDependentExtensionAnalyzer
    {
        public string Analyze(PullRequest pullRequest)
        {
            var returnAnalyzedData =
                new Dictionary<string, string>();

            // todo fill this with your logic, the returnAnalyzedData can be any kind of data structure
            foreach (var file in pullRequest.Files)
            {
                returnAnalyzedData[file.FileName] = Guid.NewGuid().ToString();
            }

            return JsonConvert.SerializeObject(returnAnalyzedData);
        }
    }
}
