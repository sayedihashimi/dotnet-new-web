﻿namespace CodeVelocity.SampleLanguageDependentExtension.Csharp
{
    using System;
    using System.Diagnostics.CodeAnalysis;
    using System.IO;
    using CodeVelocity.Abstractions;
    using Newtonsoft.Json;

    [ExcludeFromCodeCoverage]
    public static class Program
    {
        public static void Main(string[] args)
        {
            var payload = File.ReadAllText(args[0]);
            var pullRequest = JsonConvert.DeserializeObject<PullRequest>(payload);
            var analyzer = new SampleLanguageDependentExtensionAnalyzer();
            var results = analyzer.Analyze(pullRequest);
            Console.WriteLine(results);
        }
    }
}
