namespace CodeVelocity.SampleLanguageDependentExtension.Core.Tests
{
    using System.Diagnostics.CodeAnalysis;
    using System.Linq;
    using System.Threading.Tasks;
    using CodeVelocity.Abstractions;
    using CodeVelocity.Extensions.Abstractions;
    using CodeVelocity.Extensions.Abstractions.Models;
    using CodeVelocity.Extensions.Abstractions.TestData;
    using Moq;
    using Xunit;

    [ExcludeFromCodeCoverage]
    public class SampleLanguageDependentExtensionTests
    {
        private readonly Mock<ILanguageServerClient> mockLanguageServerClient;

        public SampleLanguageDependentExtensionTests()
        {
            mockLanguageServerClient = new Mock<ILanguageServerClient>();
        }

        [Fact]
        public async Task AnalyzeTest()
        {
            // Arrange
            var pullRequest = (await PullRequestSamples.Generate()).First();
            mockLanguageServerClient
                .Setup(lc => lc.Analyze(It.IsAny<LanugageCommand>(), It.IsAny<PullRequest>()))
                .ReturnsAsync(
                    (LanugageCommand languageCommand, PullRequest pr) => new ExtensionLanguageOutput
                    {
                        StdErr = string.Empty,
                        StdOut = pr.Files.Count.ToString()
                    });
            var sampleLanguageDependentExtension = new SampleLanguageDependentExtension(mockLanguageServerClient.Object);

            // Act
            var extensionOutput = await sampleLanguageDependentExtension.AnalyzePullRequest(pullRequest);

            // Assert
            Assert.Equal(sampleLanguageDependentExtension.Id, extensionOutput.Badge.Title);
            Assert.Equal(pullRequest.Files.Count, int.Parse(extensionOutput.Badge.Grade));
            Assert.Equal(Severity.Warning, extensionOutput.Badge.Severity);
        }
    }
}
