const fs = require('fs');

fileName = process.argv[2];
fs.readFile(fileName, (err, pullRequestPayload) => {
    if (err) {
        throw err;
    }
    let payloadJson = JSON.parse(pullRequestPayload);
    console.log(payloadJson['Files'].length);
});
