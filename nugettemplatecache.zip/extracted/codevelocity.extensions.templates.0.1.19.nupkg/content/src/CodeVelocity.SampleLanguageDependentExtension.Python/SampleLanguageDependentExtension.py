import json
import sys

file_name = str(sys.argv[1])
with open(file_name) as infile:
    pull_request_payload = json.load(infile)
    print(len(pull_request_payload['Files']))
